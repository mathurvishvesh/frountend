import React from 'react'
import './style.css'
import './responsive.css'
import './bootstrap.css'



const Footer = () => {
    return (
        <div>

            <footer class="container-fluid footer_section ">
                <div class="container">
                    <p>
                        &copy; <span id="displayDate"></span> All Rights Reserved By
                        <a href="https://html.design/">Free Html Templates</a>
                    </p>
                </div>
            </footer>


        </div>
    )
}

export default Footer
